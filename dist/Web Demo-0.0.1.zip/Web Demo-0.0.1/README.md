#ReadMe

## About this project

### This is the practices project for OpenStack learning.


